<script>
	$("body").empty();
	$('body').append('<div id="load-child-web"></div>');
	$('#load-child-web').load("http://127.0.0.1/child.html");  
</script>